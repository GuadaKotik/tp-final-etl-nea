# Pipeline ETL — Exportaciones del NEA (1993–2024)

Trabajo Práctico Integrador — Unidad II
Diplomatura Universitaria en Data Analytics e Inteligencia Artificial Aplicada (UNNE)

## Qué hace este pipeline

Se conecta a la **API de Series de Tiempo** de datos.gob.ar (datos del INDEC),
descarga las exportaciones de **Chaco, Corrientes, Formosa y Misiones** por
país de destino y por rubro entre 1993 y 2024, y las transforma en un único
dataset analítico:

```
API datos.gob.ar          data/raw/*.json         data/processed/
(INDEC, 8 llamadas)  -->  (crudo, sin tocar) -->  exportaciones_nea.csv
                                                   resumen.json
     EXTRACT                  TRANSFORM              CHEQUEAR + LOAD
```

El resultado es `data/processed/exportaciones_nea.csv`, con **1.408 filas
(4 provincias × 11 destinos × 32 años) y 13 columnas**: valor exportado,
participación sobre el total provincial, variación interanual, década,
ranking del destino ese año, y el rubro más exportado (cruzado desde el
dataset de rubros).

Cada corrida además produce:

- `data/processed/resumen.json`: ficha técnica del dataset (fuente, período,
  estadísticas de `valor_musd`, resultado de los quality checks).
- `logs/pipeline.log`: una línea por corrida (se agrega, nunca se borra).

## Cómo instalarlo y ejecutarlo

Requiere **Python 3.8+**. No usa librerías externas: solo la biblioteca
estándar (`urllib`, `json`, `csv`, `logging`, `datetime`).

```bash
python --version              # verificar 3.8+
python src/main.py            # corre el pipeline completo (necesita internet)
```

La primera corrida descarga los datos de la API y los guarda en
`data/raw/`. Después se puede trabajar sin conexión reutilizando lo ya
descargado:

```bash
python src/main.py --sin-internet
```

Para correr los tests:

```bash
python tests/test_transform.py
```

## De dónde salen los datos

**Fuente:** INDEC, vía la [API de Series de Tiempo](https://apis.datos.gob.ar/series/api/)
del portal de datos abiertos del Estado argentino (datos.gob.ar). Es una
API pública, sin necesidad de credenciales.

- **Dataset 357.1** — Exportaciones por provincia y país de destino.
- **Dataset 350.1** — Exportaciones por provincia y rubro.
- **Unidad:** millones de dólares FOB.
- **Período:** 1993–2024.

Los identificadores de cada serie (uno por provincia × destino, y uno por
provincia × rubro) están centralizados en `config.py`, separados del
código: si algún ID cambia en la API, se actualiza ahí y no en la lógica.

## Estructura del proyecto

```
├── config.py               Configuración: IDs de series, rutas, mapeos
├── src/
│   ├── extract.py          Descarga de la API -> data/raw/
│   ├── transform.py        Limpieza, tipado, columnas derivadas y join
│   ├── load.py             Quality checks + guardado de CSV/JSON/log
│   └── main.py             Orquesta extract -> transform -> load
├── tests/
│   └── test_transform.py   19 tests (17 de la cátedra + 2 propios)
├── data/
│   ├── raw/                 JSON crudos tal como llegan de la API
│   └── processed/           CSV y resumen.json finales
└── logs/                    Historial de corridas (pipeline.log)
```

## Decisiones de diseño

- **Manejo de errores:** si el INDEC publicó un valor nulo para algún año o
  destino, esa observación puntual se saltea (no rompe el resto del
  pipeline). Las divisiones (participación, variación interanual) devuelven
  `None` en vez de romper cuando el denominador es cero o inexistente.
- **Quality checks críticos** (cortan el pipeline si fallan): cantidad
  mínima de filas, las 13 columnas del contrato en todas las filas,
  ausencia de duplicados por `(provincia, anio, destino)`, y valores de
  `valor_musd` dentro de un rango razonable. Además hay un check de
  cobertura (no crítico) que solo deja una advertencia.
- **Idempotencia:** el CSV y el `resumen.json` se escriben en modo `"w"`,
  así que correr el pipeline varias veces con los mismos datos crudos
  produce siempre el mismo resultado. El log, en cambio, se abre en modo
  `"a"`: cada corrida agrega una línea nueva, nunca borra el historial.

## Un hallazgo en los datos

> Completar después de correr `python src/main.py` con conexión a internet:
> mirar `data/processed/exportaciones_nea.csv` (o `resumen.json`) y contar
> algo con sentido — por ejemplo, qué destino gana o pierde participación
> a lo largo de las décadas en alguna de las cuatro provincias, algún año
> con una variación interanual llamativa, o cómo cambia el peso de
> "Productos primarios" en el rubro principal de cada provincia entre los
> 1990s y los 2020s.
